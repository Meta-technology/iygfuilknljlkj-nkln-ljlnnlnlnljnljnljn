
declare module 'surveyjs';
