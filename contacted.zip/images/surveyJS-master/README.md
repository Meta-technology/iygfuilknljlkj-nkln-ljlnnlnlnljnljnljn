[![](https://data.jsdelivr.com/v1/package/gh/simplysayhi/surveyJS/badge)](https://www.jsdelivr.com/package/gh/simplysayhi/surveyJS)

# surveyJS

Visit the [Plugin Documentation Page](https://www.valeriodipunzio.com/plugins/surveyJS/) for more info.



## Changelog

See the [Changelog Page](https://www.valeriodipunzio.com/plugins/surveyJS/#changelog) for details.



## Releases

See the [Releases Page](https://github.com/SimplySayHi/surveyJS/releases) to download provious versions.



## License

MIT
